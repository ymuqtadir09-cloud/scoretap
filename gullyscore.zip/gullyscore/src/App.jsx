import { useState, useRef } from "react";

const C = {
  bg: "#0A0E0A", surface: "#111711", card: "#162016", border: "#1E2E1E",
  green: "#22C55E", greenDim: "#15803D", greenGlow: "rgba(34,197,94,0.18)",
  amber: "#F59E0B", red: "#EF4444", blue: "#3B82F6", purple: "#A855F7",
  text: "#F0FDF4", textMuted: "#6B7280", textDim: "#9CA3AF",
  four: "#3B82F6", six: "#A855F7", wide: "#F59E0B", noball: "#EF4444",
};

const overStr = (b) => `${Math.floor(b / 6)}.${b % 6}`;
const crr = (runs, balls) => balls === 0 ? "0.00" : ((runs / balls) * 6).toFixed(2);
const rrr = (need, balls) => balls === 0 ? "—" : ((need / balls) * 6).toFixed(2);
const ballColor = (b) => {
  if (b === "W") return C.red;
  if (b === "Wd") return C.wide;
  if (b === "Nb") return C.noball;
  if (b === 4) return C.four;
  if (b === 6) return C.six;
  if (b === 0) return C.textMuted;
  return C.green;
};
const ballLabel = (b) => b === "Wd" ? "Wd" : b === "Nb" ? "Nb" : b === "W" ? "W" : String(b);

function loadMatches() {
  try { const s = localStorage.getItem("gs_matches"); return s ? JSON.parse(s) : []; } catch { return []; }
}
function saveMatches(m) {
  try { localStorage.setItem("gs_matches", JSON.stringify(m)); } catch {}
}

function Pill({ children, color = C.green, style = {} }) {
  return (
    <span style={{
      display: "inline-block", borderRadius: 99, padding: "2px 10px",
      fontSize: 11, fontWeight: 600, letterSpacing: .5,
      background: color + "22", color, border: `1px solid ${color}44`, ...style
    }}>{children}</span>
  );
}

function Btn({ children, onClick, color = C.green, size = "md", disabled, style = {} }) {
  const pad = size === "lg" ? "14px 0" : size === "sm" ? "8px 14px" : "11px 0";
  return (
    <button onClick={onClick} disabled={disabled} style={{
      background: disabled ? C.border : `linear-gradient(135deg, ${color}22, ${color}11)`,
      border: `1.5px solid ${disabled ? C.border : color + "55"}`,
      borderRadius: 14, color: disabled ? C.textMuted : color,
      fontFamily: "'Space Grotesk', sans-serif", fontWeight: 700,
      fontSize: size === "lg" ? 16 : size === "sm" ? 13 : 15,
      padding: pad, cursor: disabled ? "not-allowed" : "pointer",
      transition: "all .15s", letterSpacing: .3, ...style,
    }}
      onMouseDown={e => !disabled && (e.currentTarget.style.transform = "scale(.96)")}
      onMouseUp={e => !disabled && (e.currentTarget.style.transform = "scale(1)")}
    >{children}</button>
  );
}

function Card({ children, style = {}, glow }) {
  return (
    <div style={{
      background: C.card, borderRadius: 18, border: `1px solid ${C.border}`, padding: "16px",
      ...(glow ? { animation: "glow 2.5s infinite", boxShadow: `0 0 12px 2px rgba(34,197,94,0.18)` } : {}),
      ...style
    }}>{children}</div>
  );
}

function HomeScreen({ onStart, matches }) {
  return (
    <div style={{ padding: "20px 16px 100px", animation: "slideUp .3s" }}>
      <div style={{ textAlign: "center", marginBottom: 28, paddingTop: 12 }}>
        <div style={{ fontSize: 40, marginBottom: 4 }}>🏏</div>
        <div style={{ fontFamily: "'Space Grotesk'", fontSize: 30, fontWeight: 800, color: C.green, letterSpacing: -1 }}>GullyScore</div>
        <div style={{ color: C.textMuted, fontSize: 13, marginTop: 4 }}>Your match. Your rules. No arguments.</div>
      </div>
      <Btn onClick={onStart} size="lg" style={{
        width: "100%", fontSize: 18, padding: "18px 0", borderRadius: 18,
        background: `linear-gradient(135deg, ${C.green}33, ${C.greenDim}22)`,
        border: `2px solid ${C.green}88`, animation: "glow 3s infinite"
      }}>⚡ Start New Match</Btn>
      <div style={{ marginTop: 28 }}>
        <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 15, color: C.textDim, marginBottom: 12, letterSpacing: .5 }}>RECENT MATCHES</div>
        {matches.length === 0 ? (
          <Card style={{ textAlign: "center", padding: "28px 16px" }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🏏</div>
            <div style={{ color: C.textMuted, fontSize: 14 }}>No matches played yet</div>
            <div style={{ color: C.textMuted, fontSize: 12, marginTop: 4 }}>Start a new match to see it here</div>
          </Card>
        ) : (
          matches.slice(0, 5).map((m, i) => (
            <Card key={i} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 15 }}>{m.teamA} vs {m.teamB}</div>
                  <div style={{ color: C.textMuted, fontSize: 12, marginTop: 3 }}>{m.overs} ov · {m.date}</div>
                </div>
                <div>{m.winner ? <Pill color={C.green}>{m.winner} won</Pill> : <Pill color={C.amber}>In Progress</Pill>}</div>
              </div>
            </Card>
          ))
        )}
      </div>
      <Card style={{ marginTop: 20, opacity: .5 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ fontSize: 22 }}>🏆</div>
          <div>
            <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700 }}>Tournament Mode</div>
            <div style={{ color: C.textMuted, fontSize: 12 }}>Coming Soon</div>
          </div>
          <Pill color={C.purple} style={{ marginLeft: "auto" }}>Soon</Pill>
        </div>
      </Card>
    </div>
  );
}

function SetupScreen({ onBack, onBegin }) {
  const [teamA, setTeamA] = useState("");
  const [teamB, setTeamB] = useState("");
  const [overs, setOvers] = useState(6);
  const [toss, setToss] = useState("");
  const [bat, setBat] = useState("");
  const ready = teamA.trim() && teamB.trim() && overs > 0;
  const overOpts = [4, 5, 6, 7, 8, 10, 12, 15, 20];

  const inp = (val, setter) => ({
    value: val, onChange: e => setter(e.target.value),
    style: {
      width: "100%", background: C.surface, border: `1.5px solid ${C.border}`,
      borderRadius: 12, color: C.text, fontSize: 16, padding: "13px 14px",
      fontFamily: "'Inter', sans-serif", outline: "none",
    },
    onFocus: e => (e.target.style.borderColor = C.green),
    onBlur: e => (e.target.style.borderColor = C.border),
  });

  return (
    <div style={{ padding: "16px 16px 100px", animation: "slideUp .3s" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
        <button onClick={onBack} style={{ background: "none", border: "none", color: C.textMuted, fontSize: 20, cursor: "pointer" }}>←</button>
        <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 800, fontSize: 22 }}>New Match</div>
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600, letterSpacing: .6, display: "block", marginBottom: 6 }}>TEAM A</label>
        <input {...inp(teamA, setTeamA)} placeholder="e.g. Street Lions" />
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600, letterSpacing: .6, display: "block", marginBottom: 6 }}>TEAM B</label>
        <input {...inp(teamB, setTeamB)} placeholder="e.g. Turf Tigers" />
      </div>
      <div style={{ marginBottom: 20 }}>
        <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600, letterSpacing: .6, display: "block", marginBottom: 8 }}>OVERS</label>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {overOpts.map(o => (
            <button key={o} onClick={() => setOvers(o)} style={{
              padding: "9px 16px", borderRadius: 10,
              background: overs === o ? C.green + "33" : C.surface,
              border: `1.5px solid ${overs === o ? C.green : C.border}`,
              color: overs === o ? C.green : C.textDim,
              fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'Space Grotesk'",
            }}>{o}</button>
          ))}
        </div>
      </div>
      {teamA.trim() && teamB.trim() && (
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600, letterSpacing: .6, display: "block", marginBottom: 8 }}>TOSS WON BY (optional)</label>
          <div style={{ display: "flex", gap: 8 }}>
            {[teamA, teamB].map(t => (
              <button key={t} onClick={() => setToss(t)} style={{
                flex: 1, padding: "10px", borderRadius: 10,
                background: toss === t ? C.amber + "22" : C.surface,
                border: `1.5px solid ${toss === t ? C.amber : C.border}`,
                color: toss === t ? C.amber : C.textDim,
                fontWeight: 600, fontSize: 13, cursor: "pointer",
              }}>{t}</button>
            ))}
          </div>
        </div>
      )}
      {toss && (
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 12, color: C.textMuted, fontWeight: 600, letterSpacing: .6, display: "block", marginBottom: 8 }}>BATTING FIRST</label>
          <div style={{ display: "flex", gap: 8 }}>
            {[teamA, teamB].map(t => (
              <button key={t} onClick={() => setBat(t)} style={{
                flex: 1, padding: "10px", borderRadius: 10,
                background: bat === t ? C.blue + "22" : C.surface,
                border: `1.5px solid ${bat === t ? C.blue : C.border}`,
                color: bat === t ? C.blue : C.textDim,
                fontWeight: 600, fontSize: 13, cursor: "pointer",
              }}>{t}</button>
            ))}
          </div>
        </div>
      )}
      <Btn
        onClick={() => ready && onBegin({ teamA: teamA.trim(), teamB: teamB.trim(), overs, tossWinner: toss, battingFirst: bat || teamA.trim() })}
        size="lg" disabled={!ready}
        style={{
          width: "100%", marginTop: 8,
          background: ready ? `linear-gradient(135deg, ${C.green}33, ${C.greenDim}22)` : undefined,
          border: ready ? `2px solid ${C.green}88` : undefined,
        }}
      >🏏 Start Match</Btn>
    </div>
  );
}

function OverDisplay({ overGroups }) {
  if (overGroups.length === 0) {
    return (
      <div style={{ padding: "0 16px 12px" }}>
        <div style={{ background: C.card, borderRadius: 12, padding: "10px 14px", border: `1.5px solid ${C.green}55`, boxShadow: `0 0 10px 0 rgba(34,197,94,0.18)` }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }}>
            <div style={{ fontSize: 10, color: C.green, fontWeight: 700, letterSpacing: .6 }}>OVER 1 · LIVE</div>
            <div style={{ fontSize: 10, color: C.textMuted }}>0/6 balls</div>
          </div>
          <div style={{ display: "flex", gap: 6 }}>
            {[...Array(6)].map((_, i) => (
              <div key={i} style={{ width: 30, height: 30, borderRadius: "50%", border: `1.5px dashed ${C.border}`, opacity: .4 }} />
            ))}
          </div>
        </div>
      </div>
    );
  }
  const currentIdx = overGroups.length - 1;
  const currentOver = overGroups[currentIdx];
  const currentLegal = currentOver.filter(b => b !== "Wd" && b !== "Nb").length;
  const isComplete = currentLegal === 6;
  return (
    <div style={{ padding: "0 16px 12px" }}>
      <div style={{
        background: C.card, borderRadius: 12, padding: "10px 14px",
        border: `1.5px solid ${isComplete ? C.border : C.green + "55"}`,
        boxShadow: isComplete ? "none" : `0 0 10px 0 rgba(34,197,94,0.18)`,
        marginBottom: overGroups.length > 1 ? 10 : 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 7 }}>
          <div style={{ fontSize: 10, color: isComplete ? C.textMuted : C.green, fontWeight: 700, letterSpacing: .6 }}>
            OVER {currentIdx + 1}{isComplete ? " ✓" : " · LIVE"}
          </div>
          <div style={{ fontSize: 10, color: C.textMuted }}>{currentLegal}/6 balls</div>
        </div>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          {currentOver.map((b, bi) => (
            <div key={bi} style={{
              width: 30, height: 30, borderRadius: "50%",
              background: ballColor(b) + "28", border: `2px solid ${ballColor(b)}88`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 800, color: ballColor(b),
              animation: bi === currentOver.length - 1 && !isComplete ? "pulse 1.5s infinite" : "none",
            }}>{ballLabel(b)}</div>
          ))}
          {!isComplete && [...Array(6 - currentLegal)].map((_, i) => (
            <div key={"e" + i} style={{ width: 30, height: 30, borderRadius: "50%", border: `1.5px dashed ${C.border}`, opacity: .35 }} />
          ))}
        </div>
      </div>
      {overGroups.length > 1 && (
        <div>
          <div style={{ fontSize: 10, color: C.textMuted, fontWeight: 600, letterSpacing: .6, marginBottom: 6, paddingLeft: 2 }}>PREVIOUS OVERS</div>
          {[...overGroups.slice(0, currentIdx)].reverse().map((ov, ri) => {
            const oi = currentIdx - 1 - ri;
            const overRuns = ov.reduce((acc, b) => {
              if (typeof b === "number") return acc + b;
              if (b === "Wd" || b === "Nb" || b === "B" || b === "Lb") return acc + 1;
              return acc;
            }, 0);
            return (
              <div key={oi} style={{
                background: C.surface, borderRadius: 10, padding: "8px 12px",
                border: `1px solid ${C.border}`, marginBottom: 6,
                display: "flex", alignItems: "center", gap: 10,
              }}>
                <div style={{ fontSize: 10, color: C.textMuted, fontWeight: 600, minWidth: 48 }}>OVER {oi + 1}</div>
                <div style={{ display: "flex", gap: 5, flex: 1, flexWrap: "wrap" }}>
                  {ov.map((b, bi) => (
                    <div key={bi} style={{
                      width: 24, height: 24, borderRadius: "50%",
                      background: ballColor(b) + "1A", border: `1.5px solid ${ballColor(b)}55`,
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 9, fontWeight: 700, color: ballColor(b),
                    }}>{ballLabel(b)}</div>
                  ))}
                </div>
                <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 700, minWidth: 24, textAlign: "right" }}>{overRuns}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function ScoringScreen({ match, onMatchEnd, onBack }) {
  const [innings, setInnings] = useState(1);
  const [score, setScore] = useState(0);
  const [wickets, setWickets] = useState(0);
  const [balls, setBalls] = useState([]);
  const [firstInningsScore, setFirstInningsScore] = useState(null);
  const [extras, setExtras] = useState({ wide: 0, noball: 0, bye: 0, legbye: 0 });
  const [lastPop, setLastPop] = useState(null);
  const [showInningsBreak, setShowInningsBreak] = useState(false);
  const [showMatchEnd, setShowMatchEnd] = useState(false);
  const popTimeout = useRef(null);

  const totalOvers = match.overs;
  const legalBalls = balls.filter(b => b !== "Wd" && b !== "Nb").length;
  const ballsRemaining = totalOvers * 6 - legalBalls;
  const curTeam = innings === 1 ? match.battingFirst : (match.battingFirst === match.teamA ? match.teamB : match.teamA);
  const target = firstInningsScore !== null ? firstInningsScore + 1 : null;
  const runsNeeded = target !== null ? target - score : null;
  const isChasing = innings === 2;

  const overGroups = [];
  let cur = [], legals = 0;
  for (const b of balls) {
    cur.push(b);
    if (b !== "Wd" && b !== "Nb") legals++;
    if (legals === 6) { overGroups.push(cur); cur = []; legals = 0; }
  }
  if (cur.length > 0) overGroups.push(cur);

  const totalExtras = extras.wide + extras.noball + extras.bye + extras.legbye;

  const triggerPop = (label, color) => {
    setLastPop({ label, color });
    clearTimeout(popTimeout.current);
    popTimeout.current = setTimeout(() => setLastPop(null), 700);
  };

  const addBall = (event) => {
    let runsAdded = 0, extraType = null;
    if (event === "Wd") { runsAdded = 1; extraType = "wide"; triggerPop("Wide", C.wide); }
    else if (event === "Nb") { runsAdded = 1; extraType = "noball"; triggerPop("No Ball", C.noball); }
    else if (event === "W") { triggerPop("OUT!", C.red); }
    else if (event === "B") { runsAdded = 1; extraType = "bye"; }
    else if (event === "Lb") { runsAdded = 1; extraType = "legbye"; }
    else { runsAdded = event; if (event === 4) triggerPop("FOUR!", C.four); if (event === 6) triggerPop("SIX!", C.six); }

    const newScore = score + runsAdded;
    const newWickets = event === "W" ? wickets + 1 : wickets;
    const newBalls = [...balls, event];
    const newExtras = extraType ? { ...extras, [extraType]: extras[extraType] + 1 } : extras;

    setScore(newScore); setWickets(newWickets); setBalls(newBalls); setExtras(newExtras);

    const newLegal = newBalls.filter(b => b !== "Wd" && b !== "Nb").length;
    const allOut = newWickets >= 10;
    const oversUp = newLegal >= totalOvers * 6;
    const chaseWon = isChasing && newScore >= (firstInningsScore + 1);

    if (chaseWon) { setShowMatchEnd({ winner: curTeam, margin: `${10 - newWickets} wickets`, score: `${newScore}/${newWickets}` }); return; }
    if (allOut || oversUp) {
      if (innings === 1) { setFirstInningsScore(newScore); setShowInningsBreak({ score: newScore, wickets: newWickets, team: curTeam }); }
      else {
        const lost = newScore < (firstInningsScore + 1);
        const otherTeam = curTeam === match.teamA ? match.teamB : match.teamA;
        setShowMatchEnd({ winner: lost ? otherTeam : curTeam, margin: lost ? `${firstInningsScore + 1 - newScore} runs` : `${10 - newWickets} wickets`, score: `${newScore}/${newWickets}`, firstScore: `${firstInningsScore}` });
      }
    }
  };

  const undoLast = () => {
    if (balls.length === 0) return;
    const last = balls[balls.length - 1];
    let ds = 0, dw = 0;
    if (last === "Wd" || last === "Nb" || last === "B" || last === "Lb") ds = 1;
    else if (last === "W") dw = 1;
    else ds = last;
    setScore(score - ds); setWickets(wickets - dw); setBalls(balls.slice(0, -1));
  };

  const startInnings2 = () => { setInnings(2); setScore(0); setWickets(0); setBalls([]); setExtras({ wide: 0, noball: 0, bye: 0, legbye: 0 }); setShowInningsBreak(false); };

  if (showInningsBreak) return (
    <div style={{ position: "fixed", inset: 0, background: "#0A0E0Aee", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, zIndex: 10 }}>
      <div style={{ fontSize: 40, marginBottom: 12 }}>☕</div>
      <div style={{ fontFamily: "'Space Grotesk'", fontSize: 26, fontWeight: 800, textAlign: "center", marginBottom: 8 }}>Innings Break</div>
      <div style={{ color: C.textMuted, marginBottom: 20, textAlign: "center" }}>
        {showInningsBreak.team} scored <strong style={{ color: C.green }}>{showInningsBreak.score}/{showInningsBreak.wickets}</strong>
      </div>
      <Card style={{ width: "100%", maxWidth: 340, marginBottom: 20 }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 13, color: C.textMuted, marginBottom: 4 }}>TARGET</div>
          <div style={{ fontFamily: "'Space Grotesk'", fontSize: 52, fontWeight: 800, color: C.green, lineHeight: 1 }}>{showInningsBreak.score + 1}</div>
          <div style={{ color: C.textMuted, fontSize: 13, marginTop: 4 }}>runs to win in {totalOvers} overs</div>
        </div>
      </Card>
      <Btn onClick={startInnings2} size="lg" style={{ width: "100%", maxWidth: 340 }}>Start 2nd Innings →</Btn>
    </div>
  );

  if (showMatchEnd) return (
    <div style={{ position: "fixed", inset: 0, background: "#0A0E0Aee", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24, zIndex: 10, overflowY: "auto" }}>
      <div style={{ fontSize: 52, marginBottom: 12 }}>🏆</div>
      <div style={{ fontFamily: "'Space Grotesk'", fontSize: 28, fontWeight: 800, color: C.green, textAlign: "center" }}>{showMatchEnd.winner}</div>
      <div style={{ fontFamily: "'Space Grotesk'", fontSize: 18, color: C.textMuted, marginBottom: 4, textAlign: "center" }}>won by {showMatchEnd.margin}</div>
      {showMatchEnd.firstScore && <div style={{ color: C.textMuted, fontSize: 13, marginBottom: 20 }}>1st innings: {showMatchEnd.firstScore} · 2nd innings: {showMatchEnd.score}</div>}
      <Btn onClick={() => onMatchEnd({ ...match, winner: showMatchEnd.winner, finalScore: showMatchEnd.score, date: new Date().toLocaleDateString("en-IN") })}
        size="lg" style={{ width: "100%", maxWidth: 340, marginTop: 12 }}>View Summary</Btn>
    </div>
  );

  return (
    <div style={{ padding: "0 0 120px", animation: "slideUp .3s" }}>
      <div style={{ background: C.surface, borderBottom: `1px solid ${C.border}`, padding: "12px 16px", display: "flex", alignItems: "center", gap: 10, position: "sticky", top: 0, zIndex: 5 }}>
        <button onClick={onBack} style={{ background: "none", border: "none", color: C.textMuted, fontSize: 18, cursor: "pointer" }}>←</button>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 14 }}>{match.teamA} vs {match.teamB}</div>
          <div style={{ color: C.textMuted, fontSize: 11 }}>Innings {innings} · {curTeam} batting</div>
        </div>
        <Pill color={innings === 1 ? C.green : C.amber}>Innings {innings}</Pill>
      </div>
      <div style={{ background: `linear-gradient(180deg, ${C.card} 0%, ${C.bg} 100%)`, padding: "20px 16px 16px", textAlign: "center", position: "relative" }}>
        {lastPop && (
          <div style={{ position: "absolute", top: 12, right: 16, fontFamily: "'Space Grotesk'", fontWeight: 800, fontSize: 20, color: lastPop.color, animation: "pop .7s forwards" }}>
            {lastPop.label}
          </div>
        )}
        <div style={{ fontFamily: "'Space Grotesk'", fontSize: 64, fontWeight: 800, lineHeight: 1, color: C.text, letterSpacing: -3 }}>
          {score}<span style={{ color: C.textMuted, fontSize: 40 }}>/{wickets}</span>
        </div>
        <div style={{ fontFamily: "'Space Grotesk'", fontSize: 18, color: C.green, marginTop: 4 }}>
          {overStr(legalBalls)} ov
          {legalBalls > 0 && <span style={{ color: C.textMuted, fontSize: 14, marginLeft: 10 }}>CRR {crr(score, legalBalls)}</span>}
        </div>
        {isChasing && target && (
          <div style={{ marginTop: 10, display: "flex", justifyContent: "center", gap: 20 }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 22, color: runsNeeded <= 0 ? C.green : C.amber }}>{runsNeeded > 0 ? runsNeeded : "WON!"}</div>
              <div style={{ fontSize: 11, color: C.textMuted }}>runs needed</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 22, color: C.blue }}>{ballsRemaining}</div>
              <div style={{ fontSize: 11, color: C.textMuted }}>balls left</div>
            </div>
            <div style={{ textAlign: "center" }}>
              <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700, fontSize: 22, color: C.purple }}>{rrr(runsNeeded, ballsRemaining)}</div>
              <div style={{ fontSize: 11, color: C.textMuted }}>req. RR</div>
            </div>
          </div>
        )}
      </div>
      <OverDisplay overGroups={overGroups} />
      <div style={{ padding: "0 16px" }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 10 }}>
          {[0, 1, 2, 3, 4, 6].map(r => (
            <Btn key={r} onClick={() => addBall(r)} size="lg"
              color={r === 4 ? C.four : r === 6 ? C.six : r === 0 ? C.textMuted : C.green}
              style={{ fontSize: 24, padding: "18px 0", borderRadius: 16 }}>{r}</Btn>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginBottom: 10 }}>
          {[["Wd", "Wide", C.amber], ["Nb", "No Ball", C.noball], ["B", "Bye", C.blue], ["Lb", "Leg Bye", C.purple]].map(([ev, label, col]) => (
            <Btn key={ev} onClick={() => addBall(ev)} color={col} size="sm" style={{ fontSize: 11, padding: "10px 4px" }}>{label}</Btn>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          <Btn onClick={() => addBall("W")} color={C.red} size="lg" style={{ fontSize: 16, padding: "16px 0", borderRadius: 16 }}>🔴 Wicket</Btn>
          <Btn onClick={undoLast} color={C.textMuted} size="lg" disabled={balls.length === 0} style={{ fontSize: 15, padding: "16px 0", borderRadius: 16 }}>↩ Undo</Btn>
        </div>
        {totalExtras > 0 && (
          <Card style={{ marginTop: 14 }}>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 8, fontWeight: 600, letterSpacing: .5 }}>EXTRAS: {totalExtras}</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {extras.wide > 0 && <Pill color={C.amber}>Wd {extras.wide}</Pill>}
              {extras.noball > 0 && <Pill color={C.noball}>Nb {extras.noball}</Pill>}
              {extras.bye > 0 && <Pill color={C.blue}>B {extras.bye}</Pill>}
              {extras.legbye > 0 && <Pill color={C.purple}>Lb {extras.legbye}</Pill>}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function SummaryScreen({ match, onHome }) {
  return (
    <div style={{ padding: "20px 16px 80px", animation: "slideUp .3s" }}>
      <div style={{ textAlign: "center", marginBottom: 24 }}>
        <div style={{ fontSize: 48, marginBottom: 8 }}>🏆</div>
        <div style={{ fontFamily: "'Space Grotesk'", fontSize: 28, fontWeight: 800, color: C.green }}>{match.winner}</div>
        <div style={{ color: C.textMuted, fontSize: 14, marginTop: 4 }}>won the match</div>
      </div>
      <Card glow style={{ marginBottom: 14, textAlign: "center" }}>
        <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 6 }}>FINAL SCORE</div>
        <div style={{ fontFamily: "'Space Grotesk'", fontSize: 36, fontWeight: 800 }}>{match.finalScore}</div>
        <div style={{ color: C.textMuted, fontSize: 13, marginTop: 4 }}>{match.teamA} vs {match.teamB} · {match.overs} overs</div>
      </Card>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 14 }}>
        {[["Date", match.date], ["Overs", match.overs], ["Venue", match.location || "Local Ground"], ["Format", `T${match.overs}`]].map(([k, v]) => (
          <Card key={k} style={{ textAlign: "center" }}>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>{k.toUpperCase()}</div>
            <div style={{ fontFamily: "'Space Grotesk'", fontWeight: 700 }}>{v}</div>
          </Card>
        ))}
      </div>
      <Btn onClick={onHome} size="lg" style={{ width: "100%" }}>← Back to Home</Btn>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState("home");
  const [currentMatch, setCurrentMatch] = useState(null);
  const [matches, setMatches] = useState(() => loadMatches());

  const handleBegin = (setup) => { setCurrentMatch(setup); setScreen("scoring"); };
  const handleMatchEnd = (m) => {
    const updated = [m, ...matches];
    setMatches(updated); saveMatches(updated);
    setCurrentMatch(m); setScreen("summary");
  };

  return (
    <div style={{ maxWidth: 430, margin: "0 auto", minHeight: "100vh", background: C.bg }}>
      {screen === "home" && <HomeScreen onStart={() => setScreen("setup")} matches={matches} />}
      {screen === "setup" && <SetupScreen onBack={() => setScreen("home")} onBegin={handleBegin} />}
      {screen === "scoring" && currentMatch && <ScoringScreen match={currentMatch} onMatchEnd={handleMatchEnd} onBack={() => setScreen("home")} />}
      {screen === "summary" && currentMatch && <SummaryScreen match={currentMatch} onHome={() => setScreen("home")} />}
    </div>
  );
}